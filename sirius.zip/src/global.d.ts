/// <reference path="../node_modules/levilamina/types/index.d.ts"/>

declare module '*package.json' {
  const value: any;
  export default value;
}
