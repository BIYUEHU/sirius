/// <reference path="index.d.ts" />
declare class ByteBuffer extends ArrayBuffer{}