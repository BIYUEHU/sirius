/// <reference path="BlockEntity.d.ts" />
