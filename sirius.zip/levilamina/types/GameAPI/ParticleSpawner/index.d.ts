/// <reference path="ParticleSpawner.d.ts"/>
/// <reference path="mc.d.ts" />
