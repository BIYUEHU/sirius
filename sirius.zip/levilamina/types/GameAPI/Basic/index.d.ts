/// <reference path="IntPos.d.ts" />
/// <reference path="FloatPos.d.ts" />
/// <reference path="DirectionAngle.d.ts" />
/// <reference path="mc.d.ts" />
/// <reference path="types.d.ts" />
