/// <reference path="Entity.d.ts" />
/// <reference path="ActorDamageCause.d.ts" />
/// <reference path="mc.d.ts" />
