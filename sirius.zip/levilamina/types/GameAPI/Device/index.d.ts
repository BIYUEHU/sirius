/// <reference path="Device.d.ts" />
